/**

This program creates a slideshow of the top 5 travel destinations.
It allows the user to navigate through the slides using the "previous" and "next" buttons.
The program uses CardLayout to manage the image and text slides, and each slide is stored in a separate panel.
The image slides are retrieved from the resource folder and resized using the getResizeIcon() method.
The text slides are retrieved using the getTextDescription() method.
This program is designed to be easily modified by future developers.
The slides and text are stored in separate data structures, and the algorithm for creating the slideshow is clearly defined in the initComponent() method.
The goPrevious() and goNext() methods handle the functionality of the "previous" and "next" buttons.
*/

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;

public class SlideShow extends JFrame {


	// Declare variables for the buttons, panels, and frames for the slideshow
	private JPanel slidePane; // panel that holds the slideshow images
	private JPanel textPane; // panel that holds the text descriptions for each image
	private JPanel buttonPane; // panel that holds the previous and next buttons
	private CardLayout card; // layout for the slidePane
	private CardLayout cardText; // layout for the textPane
	private JButton btnPrev; // button to go to the previous image
	private JButton btnNext; // button to go to the next image
	private JLabel lblSlide; // label that displays the current image
	private JLabel lblTextArea; // label that displays the text description for the current image

	/**
	 * Create the application and call the initComponent method below to initialize.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		//Initialize variables to empty objects
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();
		textPane = new JPanel();
		textPane.setBackground(Color.GRAY);// set the background color for the text pane
		textPane.setBounds(5, 470, 790, 50);// set the position and size of the text pane
		textPane.setVisible(true);
		buttonPane = new JPanel();
		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		//Setup frame attributes
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Top 5 Destinations SlideShow");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Setting the layouts for the panels
		slidePane.setLayout(card);
		textPane.setLayout(cardText);
		
// Add each of the slides and text to their respective panels and link them to the previous and next buttons
// The algorithm below uses a postfix increment operator that assigns a number first, then adds one to the given value incrementally
// This algorithm is then linked to the previous and next buttons which identify which number the increment operator assigned, 
// and uses that number to pull from both data structures and combine them into one slide frame 
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));
			lblTextArea.setText(getTextDescription(i));
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);

		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {
// Add an action listener to the previous button to go back to the previous slide and text description

			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
//calls to the Next button and adds text
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		getContentPane().add(buttonPane, BorderLayout.SOUTH);
	}

	/**This code block contains a method called goPrevious(), which is part of the initComponent method's algorithm.
	 *  It is responsible for enabling the functionality of the "previous" button in the slideshow. 
	 *  The card object represents the CardLayout being used for the image slides, and the cardText object represents the CardLayout being used for the text slides. 
	 *  This method uses the previous() method of both card and cardText objects to go back one slide in the slideshow, corresponding to the previous button press
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}
	
	/**
	The Next Button Functionality is implemented in this method. It is linked to the previous code to add the ability to
	increment the current slide number by one, then move to the next slide pane accordingly.
	*/
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	/**

	This method, getResizeIcon(), is a data structure that stores image and image sizing data.
	It has been updated to retrieve images from the resource folder and define their measurements.
	The method returns the image based on the integer value passed as the parameter 'i'.
	This value is used in the button code to determine which image to display.
	Images are linked to this structure through the use of getClass().getResource() method.
	*/
	private String getResizeIcon(int i) {
		String image = ""; 
		if (i==1){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/alaska.jpg") + "'</body></html>";
		} else if (i==2){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/New york.jpg") + "'</body></html>";
		} else if (i==3){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/vegas.jpeg") + "'</body></html>";
		} else if (i==4){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Miami.jpg") + "'</body></html>";
		} else if (i==5){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Disneyworld.jpg") + "'</body></html>";
		}
		return image;
	}
	
	/**

	The getTextDescription method stores descriptive data for each image in a data structure.
	This method returns the text value for each slideshow image, which is displayed with the image.
	The button code pulls data from this structure to determine which text to display for each image.
	*/
	
	private String getTextDescription(int i) {
		String text = ""; 
		if (i==1){
			text = "<html><body><font size='5'>#1 Alaska.</font> <br>Alaska's raw and untamed beauty beckons adventurers from around the world to experience the ultimate wilderness escape.</body></html>";
		} else if (i==2){
			text = "<html><body><font size='5'>#2 New York.</font> <br>New York: a cultural melting pot of iconic landmarks, world-renowned museums, and endless inspiration for artists and dreamers alike.</body></html>";
		} else if (i==3){
			text = "<html><body><font size='5'>#3 Las Vegas.</font> <br>Las Vegas, the dazzling entertainment capital of the world, beckons visitors with its glittering lights, world-class shows, and non-stop excitement</body></html>";
		} else if (i==4){
			text = "<html><body><font size='5'>#4 Miami, FL.</font> <br>The awe-inspiring Miami, leaves visitors spellbound with its timeless beauty.</body></html>";
		} else if (i==5){
			text = "<html><body><font size='5'>#5 Disneyworld.</font> <br>Disneyworld: Where childhood dreams come to life, and visitors of all ages experience enchantment, wonder, and endless fun.</body></html>";
		}
		return text;
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}