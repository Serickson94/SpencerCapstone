-- Creates a new database named Top5Destinations, which can be used to store data related to the top 5 travel destinations.
-- This query can be executed in any SQL environment or command line tool that supports SQL commands.
CREATE DATABASE Top5Destinations;
/* Creates a new table named "destinations" in the current database, with the following columns:
    - id: an integer that is automatically generated for each new row, and serves as the primary key of the table
    - name: a string of up to 255 characters that represents the name of the destination, and cannot be null
    - image: a text field that stores the URL or path of an image associated with the destination, and cannot be null
    - description: a text field that stores a longer description of the destination, and cannot be null
    - rating: an integer that represents the rating of the destination, and cannot be null
  This table can be used to store information about the top five travel destinations, including their names, descriptions, and ratings.
  The "id" column is set as the primary key, which ensures that each row has a unique identifier. 
  The "NOT NULL" constraint ensures that none of the columns can be empty or null. 
  This query can be executed in any MySQL environment or command line tool that supports SQL commands.
*/
CREATE TABLE destinations (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  image TEXT NOT NULL,
  description TEXT NOT NULL,
  rating INT NOT NULL,
  PRIMARY KEY (id)
);
/* This SQL query inserts five records into the 'destinations' table, each representing a popular travel destination.
 The records include the destination name, image URL, description, and popularity rating on a scale of 1 to 5.
 The destinations include Alaska, New York, Las Vegas, Miami, and Disneyworld. */
INSERT INTO destinations (name, image, description, rating)
VALUES 
('Alaska', 'https://pizzainmotion.boardingarea.com/wp-content/uploads/2017/06/bigstock-Glacier-Bay-cruise-Alaska-na-188821333.jpg', 'Alaska''s raw and untamed beauty beckons adventurers from around the world to experience the ultimate wilderness escape.', 1),
('New York', 'https://media.collegetimes.com/uploads/2016/04/20040149/nyc.jpg', 'New York: a cultural melting pot of iconic landmarks, world-renowned museums, and endless inspiration for artists and dreamers alike.', 2),
('Las Vegas', 'https://ticketbusters.com/wp-content/uploads/2017/11/shutterstock_566096056.jpg', 'Las Vegas, the dazzling entertainment capital of the world, beckons visitors with its glittering lights, world-class shows, and non-stop excitement', 3),
('Miami, FL', 'https://sobevillas.com/wp-content/uploads/2015/10/shutterstock_142322284.jpg', 'The awe-inspiring Miami, leaves visitors spellbound with its timeless beauty.', 4),
('Disneyworld', 'https://universalparksblog.com/wp-content/uploads/2020/10/056e3152e89f51cf5922cd17bf8f6fae9e-disney-orlando.rsquare.w1200.jpg', 'Disneyworld: Where childhood dreams come to life, and visitors of all ages experience enchantment, wonder, and endless fun.', 5);

-- This SQL query selects all columns from the 'destinations' table and returns all rows.
-- It can be used to test the ability of the database to retrieve and display all data in the 'destinations' table.
SELECT * FROM destinations;

-- This SQL query selects only the 'name' and 'rating' columns from the 'destinations' table where the 'rating' value is greater than 3. 
-- It can be used to test the ability of the database to retrieve specific columns and filter data based on certain criteria.
SELECT name, rating FROM destinations WHERE rating > 3;

-- This SQL query counts the number of rows in the 'destinations' table and returns the count as a single value. 
-- It can be used to test the ability of the database to perform aggregate functions
-- and return summary statistics about the data in the 'destinations' table.
SELECT COUNT(*) FROM destinations;


