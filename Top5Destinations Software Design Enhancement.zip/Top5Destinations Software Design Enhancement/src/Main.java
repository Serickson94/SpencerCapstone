// This is a Java class for a slideshow GUI application. The class extends the
// JFrame class and contains methods to initialize the GUI components and handle
// user events.

// The header of the file imports necessary classes from the java.awt and
// javax.swing packages for creating GUI components, handling user events, and
// managing dates and times. The purpose of this header is to ensure that any
// programmer can easily understand the dependencies of the class and use it in
// their own projects.

// The class contains instance variables for the panels, buttons, labels, and
// timer required for the slideshow. It also declares constants for the duration
// of each slide in milliseconds. The initComponent() method initializes these
// variables by setting their attributes and creating new instances of them.

// The class contains an ActionListener that is attached to a Timer object to
// handle the automatic advancement of the slides. The ActionListener calculates
// the elapsed time since the timer started, updates the timer label, and
// advances to the next slide if the timer has expired. The initComponent()
// method initializes the timer object with the slide duration and starts it.

// The class contains a loop that adds each slide image and its corresponding
// text description to their respective panels. The loop uses a postfix
// increment operator to assign a number to each slide and text description and
// link them to the previous and next buttons.

// The class adds the slide and text panels, the previous and next buttons, and
// the timer controls to the JFrame using the BorderLayout manager. The previous
// and next buttons have action listeners that call the goPrevious() and
// goNext() methods to move to the previous or next slide and text description.

// Overall, this Java class provides a simple and intuitive interface for
// displaying a slideshow of images and text descriptions, with automatic and
// manual control options. It can be easily modified and extended by other
// programmers to fit their specific needs.

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Main extends JFrame {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
// Declare variables for the buttons, panels, and frames for the slideshow
  private JPanel slidePane; // panel that holds the slideshow images
  private JPanel
      textPane; // panel that holds the text descriptions for each image
  private JPanel buttonPane; // panel that holds the previous and next buttons
  private JPanel timerPane; // panel that holds the timer controls
  private CardLayout card; // layout for the slidePane
  private CardLayout cardText; // layout for the textPane
  private JButton btnPrev; // button to go to the previous image
  private JButton btnNext; // button to go to the next image
  private JLabel lblSlide; // label that displays the current image
  private JLabel lblTextArea; // label that displays the text description for
                              // the current image
  private JLabel lblTimer; // label that displays the current time
  private JButton btnPause; // button to pause the timer
  private JButton btnResume; // button to resume the timer
  private Timer timer; // timer object to track the elapsed time
  private long startTime; // start time of the timer
  private long pauseTime; // time when the timer was paused

  // Duration of each slide in milliseconds
  private final int SLIDE_DURATION = 5000;

  /**
   * Create the application and call the initComponent method below to
   * initialize.
   */
  public Main() throws HeadlessException {
    initComponent();
  }

  /**
   * Initialize the contents of the frame.
   */
  private void initComponent() {
    // Initialize variables to empty objects
    card = new CardLayout();
    cardText = new CardLayout();
    slidePane = new JPanel();
    textPane = new JPanel();
    textPane.setBackground(
        Color.GRAY); // set the background color for the text pane
    textPane.setBounds(
        5, 470, 790, 50); // set the position and size of the text pane
    textPane.setVisible(true);
    buttonPane = new JPanel();
    timerPane = new JPanel();
    btnPrev = new JButton();
    btnNext = new JButton();
    btnPause = new JButton();
    btnResume = new JButton();
    lblSlide = new JLabel();
    lblTextArea = new JLabel();
    lblTimer = new JLabel("00:00:00"); // initialize the timer label to 00:00:00

    // Initialize the start time of the timer
    startTime = System.currentTimeMillis();

    // Initialize the timer object with the slide duration and an ActionListener
    timer = new Timer(SLIDE_DURATION, new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        // Calculate the elapsed time since the timer started
        long elapsedTime = System.currentTimeMillis() - startTime - pauseTime;

        // Format the elapsed time as a string and update the timer label
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        lblTimer.setText(dateFormat.format(new Date(elapsedTime)));

        // Advance to the next slide if the timer has expired
        if (elapsedTime >= SLIDE_DURATION) {
          goNext();
        }
      }
    });

    // Start the timer object
    timer.start();

    // Setup frame attributes
    setSize(800, 600);
    setLocationRelativeTo(null);
    setTitle("Top 5 Destinations SlideShow");
    getContentPane().setLayout(new BorderLayout(10, 50));
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    // Setting the layouts for the panels
    slidePane.setLayout(card);
    textPane.setLayout(cardText);

    // Add each of the slides and text to their respective panels and link them
    // to the previous and next buttons The algorithm below uses a postfix
    // increment operator that assigns a number first, then adds one to the
    // given value incrementally This algorithm is then linked to the previous
    // and next buttons which identify which number the increment operator
    // assigned, and uses that number to pull from both data structures and
    // combine them into one slide frame
    for (int i = 1; i <= 5; i++) {
      lblSlide = new JLabel();
      lblTextArea = new JLabel();
      lblSlide.setText(getResizeIcon(i));
      lblTextArea.setText(getTextDescription(i));
      slidePane.add(lblSlide, "card" + i);
      textPane.add(lblTextArea, "cardText" + i);
    }

    getContentPane().add(slidePane, BorderLayout.CENTER);
    getContentPane().add(textPane, BorderLayout.SOUTH);

    buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 80, 10));
    btnPrev.setText("Previous");
    btnPrev.addActionListener(new ActionListener() {
      // Add an action listener to the previous button to go back to the
      // previous slide and text description

      @Override
      public void actionPerformed(ActionEvent e) {
        goPrevious();
      }
    });
    // calls to the Next button and adds text
    buttonPane.add(btnPrev);

    btnNext.setText("Next");
    btnNext.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        goNext();
      }
    });
    buttonPane.add(btnNext);

    getContentPane().add(buttonPane, BorderLayout.SOUTH);
  }

  /**This code block contains a method called goPrevious(), which is part of the
   * initComponent method's algorithm. It is responsible for enabling the
   * functionality of the "previous" button in the slideshow. The card object
   * represents the CardLayout being used for the image slides, and the cardText
   * object represents the CardLayout being used for the text slides. This
   * method uses the previous() method of both card and cardText objects to go
   * back one slide in the slideshow, corresponding to the previous button press
   */
  private void goPrevious() {
    card.previous(slidePane);
    cardText.previous(textPane);
  }

  /**
  The Next Button Functionality is implemented in this method. It is linked to
  the previous code to add the ability to increment the current slide number by
  one, then move to the next slide pane accordingly.
  */
  private void goNext() {
    card.next(slidePane);
    cardText.next(textPane);

    // Set up timer panel and buttons
    timerPane.setLayout(new FlowLayout(FlowLayout.CENTER, 80, 10));
    btnPause.setText("Pause");
    btnPause.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        timer.stop();
        pauseTime = System.currentTimeMillis() - startTime - pauseTime;
      }
    });
    timerPane.add(btnPause);

    btnResume.setText("Resume");
    btnResume.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        startTime = System.currentTimeMillis();
        timer.start();
      }
    });
    timerPane.add(btnResume);

    lblTimer.setHorizontalAlignment(JLabel.CENTER);
    timerPane.add(lblTimer);

    // Add timer pane to frame
    getContentPane().add(timerPane, BorderLayout.NORTH);
  }
  private void pauseTimer() {
    timer.stop();
    pauseTime = System.currentTimeMillis();
  }

  private void resumeTimer() {
    timer.start();
    startTime += System.currentTimeMillis() - pauseTime;

    // Initialize timer object
    timer = new Timer(1000, new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        updateTime();
      }
    });
    timer.start();
    startTime = System.currentTimeMillis();
  }
  private void updateTime() {
    long elapsedTime = (System.currentTimeMillis() - startTime) / 1000;
    long hours = elapsedTime / 3600;
    long minutes = (elapsedTime % 3600) / 60;
    long seconds = elapsedTime % 60;

    SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
    String time = formatter.format(
        new Date(hours * 3600 * 1000 + minutes * 60 * 1000 + seconds * 1000));
    lblTimer.setText(time);
  }

  /**

  This method, getResizeIcon(), is a data structure that stores image and image
  sizing data. It has been updated to retrieve images from the resource folder
  and define their measurements. The method returns the image based on the
  integer value passed as the parameter 'i'. This value is used in the button
  code to determine which image to display. Images are linked to this structure
  through the use of getClass().getResource() method.
  */
  private String getResizeIcon(int i) {
    String image = "";
    if (i == 1) {
      image = "<html><body><img width= '800' height='500' src='"
          + getClass().getResource("/resources/alaska.jpg") + "'</body></html>";
    } else if (i == 2) {
      image = "<html><body><img width= '800' height='500' src='"
          + getClass().getResource("/resources/New york.jpg")
          + "'</body></html>";
    } else if (i == 3) {
      image = "<html><body><img width= '800' height='500' src='"
          + getClass().getResource("/resources/vegas.jpeg") + "'</body></html>";
    } else if (i == 4) {
      image = "<html><body><img width= '800' height='500' src='"
          + getClass().getResource("/resources/Miami.jpg") + "'</body></html>";
    } else if (i == 5) {
      image = "<html><body><img width= '800' height='500' src='"
          + getClass().getResource("/resources/Disneyworld.jpg")
          + "'</body></html>";
    }
    return image;
  }

  /**

  The getTextDescription method stores descriptive data for each image in a data
  structure. This method returns the text value for each slideshow image, which
  is displayed with the image. The button code pulls data from this structure to
  determine which text to display for each image.
  */

  private String getTextDescription(int i) {
    String text = "";
    if (i == 1) {
      text =
          "<html><body><font size='5'>#1 Alaska.</font> <br>Alaska's raw and untamed beauty beckons adventurers from around the world to experience the ultimate wilderness escape.</body></html>";
    } else if (i == 2) {
      text =
          "<html><body><font size='5'>#2 New York.</font> <br>New York: a cultural melting pot of iconic landmarks, world-renowned museums, and endless inspiration for artists and dreamers alike.</body></html>";
    } else if (i == 3) {
      text =
          "<html><body><font size='5'>#3 Las Vegas.</font> <br>Las Vegas, the dazzling entertainment capital of the world, beckons visitors with its glittering lights, world-class shows, and non-stop excitement</body></html>";
    } else if (i == 4) {
      text =
          "<html><body><font size='5'>#4 Miami, FL.</font> <br>The awe-inspiring Miami, leaves visitors spellbound with its timeless beauty.</body></html>";
    } else if (i == 5) {
      text =
          "<html><body><font size='5'>#5 Disneyworld.</font> <br>Disneyworld: Where childhood dreams come to life, and visitors of all ages experience enchantment, wonder, and endless fun.</body></html>";
    }
    return text;
  }

  /**
   * Launch the application.
   */
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
      @Override
      public void run() {
        Main ss = new Main();
        ss.setVisible(true);
      }
    });
  }
}